import { build } from "esbuild";
import { mkdir, readFile, writeFile } from "node:fs/promises";
const result = await build({
  entryPoints: ["src/scene.js"],
  bundle: true,
  alias: { papercraft: "./vendor/papercraft" },
  format: "iife",
  minify: true,
  write: false,
  legalComments: "inline",
});
const template = await readFile("src/page.html", "utf8");
const licenses = await Promise.all(
  ["vendor/papercraft/LICENSE", "node_modules/three/LICENSE"].map((p) =>
    readFile(p, "utf8"),
  ),
);
const script = result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
await mkdir("dist", { recursive: true });
await writeFile(
  "dist/index.html",
  template.replace(
    "<!-- bundle -->",
    () =>
      "<script>\n" +
      script +
      "\n</script>\n<!--\n" +
      licenses.join("\n") +
      "\n-->",
  ),
);
