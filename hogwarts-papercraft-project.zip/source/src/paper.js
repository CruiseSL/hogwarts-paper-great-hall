import * as THREE from "three";
import { makeCard, paperMaterial } from "papercraft/lib/paperkit-3d.js";
import { shade } from "papercraft/lib/paperkit-2d.js";

export const rect = (w, h) => [
  [-w / 2, 0],
  [w / 2, 0],
  [w / 2, h],
  [-w / 2, h],
];
export const oval = (w, h, n = 20) =>
  Array.from({ length: n }, (_, i) => [
    (Math.cos((i * 2 * Math.PI) / n) * w) / 2,
    ((1 + Math.sin((i * 2 * Math.PI) / n)) * h) / 2,
  ]);
export const poly = (g, points) => {
  g.beginPath();
  points.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
  g.closePath();
  g.fill();
};
export const dot = (g, x, y, rx, ry = rx) => {
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  g.fill();
};
export const bar = (g, x0, y0, x1, y1, thickness) => {
  const a = Math.atan2(y1 - y0, x1 - x0),
    dx = (Math.sin(a) * thickness) / 2,
    dy = (Math.cos(a) * thickness) / 2;
  poly(g, [
    [x0 - dx, y0 + dy],
    [x1 - dx, y1 + dy],
    [x1 + dx, y1 - dy],
    [x0 + dx, y0 - dy],
  ]);
};
export function print(base, layers = []) {
  return (P) => {
    P.gradient(shade(base, 0.06), shade(base, -0.08), 0.55);
    for (const [color, draw] of layers)
      P.layer(
        (g) => {
          g.translate(P.box.x0, P.box.y0);
          g.scale(P.box.w, P.box.h);
          g.fillStyle = color;
          draw(g);
        },
        color,
        { depth: 0.7, rim: 0.12 },
      );
  };
}
const cache = new WeakMap();
export function card(
  H,
  parent,
  points,
  paint,
  {
    x = 0,
    y = 0,
    z = 0,
    yaw = 0,
    pitch = 0,
    name = "",
    thickness = 0.065,
  } = {},
) {
  let pool = cache.get(paint);
  if (!pool) {
    pool = new Map();
    cache.set(paint, pool);
  }
  const key = JSON.stringify([points, thickness]);
  if (!pool.has(key))
    pool.set(
      key,
      makeCard(points, {
        paint,
        paper: H.paper,
        thickness,
        edgeWidth: 0.035,
        folds: [],
        pxPerUnit: 37,
        seed: 73,
        back: "mirror",
      }),
    );
  const m = pool.get(key).clone();
  m.position.set(x, y, z);
  m.rotation.order = "YXZ";
  m.rotation.set(pitch, yaw, 0, "YXZ");
  m.name = name;
  parent.add(m);
  return m;
}
export const group = () => new THREE.Group();

const paints = new Map(),
  solids = new Map(),
  geom = new Map();
export const pigment = (color) => {
  if (!paints.has(color)) paints.set(color, print(color));
  return paints.get(color);
};
export function foldedSolid(H, parent, coords, shape, color) {
  const [x, y, z] = coords;
  const key = shape.join("/");
  if (!geom.has(key)) {
    const [kind, a, b, c, d] = shape;
    geom.set(
      key,
      kind === "box"
        ? new THREE.BoxGeometry(a, b, c)
        : new THREE.CylinderGeometry(a, b, c, d || 8),
    );
  }
  if (!solids.has(color)) {
    const m = paperMaterial({ color, map: H.paper.map });
    solids.set(color, m);
  }
  const mesh = new THREE.Mesh(geom.get(key), solids.get(color));
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
