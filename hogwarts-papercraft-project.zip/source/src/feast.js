import { InstancedMesh, Matrix4 } from "three";
import {
  card,
  group,
  oval,
  poly,
  dot,
  bar,
  print,
  pigment,
  foldedSolid,
} from "./paper.js";

const pastry = "#d99b4e",
  butter = "#ffe0a1",
  berry = "#a33850",
  leaf = "#578057",
  bone = "#f5dfb4";
// The top is an illustrated cut edge on an actual folded base, visible from the walking camera.
function top(H, n, points, paint, y, z = 0) {
  return card(H, n, points, paint, {
    y,
    z,
    pitch: -Math.PI / 2,
    thickness: 0.03,
  });
}
function roundTop(H, n, w, d, paint, y, x = 0, z = 0) {
  const sheet = top(H, n, oval(w, d), paint, y, z + d / 2);
  sheet.position.x = x;
  return sheet;
}
function band(
  H,
  n,
  x,
  y,
  z,
  rt,
  rb,
  height,
  color,
  wide = 1,
  deep = 1,
  sides = 9,
) {
  const m = foldedSolid(
    H,
    n,
    [x, y, z],
    ["cone", rt, rb, height, sides],
    color,
  );
  m.scale.set(wide, 1, deep);
  return m;
}
const lattice = print("#9f4236", [
  [
    pastry,
    (g) => {
      for (let i = -3; i <= 4; i++) {
        bar(g, i * 0.26, 0, i * 0.26 + 0.8, 1, 0.075);
        bar(g, i * 0.26, 0, i * 0.26 - 0.8, 1, 0.075);
      }
    },
  ],
  [
    butter,
    (g) => {
      g.beginPath();
      g.ellipse(0.5, 0.5, 0.44, 0.44, 0, 0, Math.PI * 2);
      g.lineWidth = 0.083;
      g.strokeStyle = butter;
      g.stroke();
    },
  ],
]);
const roastSkin = print("#bb6538", [
  [
    "#efab5b",
    (g) => {
      dot(g, 0.39, 0.6, 0.21, 0.15);
      bar(g, 0.52, 0.42, 0.73, 0.52, 0.064);
    },
  ],
  [
    "#834533",
    (g) => {
      bar(g, 0.23, 0.35, 0.49, 0.44, 0.045);
      bar(g, 0.36, 0.27, 0.62, 0.35, 0.042);
    },
  ],
]);
const icing = print("#f3cdb5", [
  [
    berry,
    (g) => {
      for (const [x, y] of [
        [0.36, 0.61],
        [0.52, 0.72],
        [0.69, 0.54],
      ]) {
        dot(g, x, y, 0.092, 0.105);
      }
    },
  ],
  ["#dba18c", (g) => bar(g, 0.17, 0.26, 0.82, 0.27, 0.05)],
]);
const cheese = print("#f0bd62", [
  [
    "#c48646",
    (g) => {
      dot(g, 0.28, 0.4, 0.09);
      dot(g, 0.56, 0.72, 0.06);
      dot(g, 0.72, 0.28, 0.08);
    },
  ],
]);
const leaves = print("#539064", [
  ["#c3bc79", (g) => bar(g, 0.14, 0.15, 0.89, 0.83, 0.09)],
]);
const apple = print("#bc4b3f", [
  [butter, (g) => dot(g, 0.3, 0.65, 0.135, 0.17)],
]);
const herb = (H, n, x, z, y, s = 1) => {
  const m = top(
    H,
    n,
    [
      [0, 0],
      [0.31 * s, 0.03 * s],
      [0.46 * s, 0.25 * s],
      [0.17 * s, 0.22 * s],
    ],
    leaves,
    y,
    z,
  );
  m.position.x = x;
};
function pie(H, n) {
  band(H, n, 0, 0.15, 0, 0.54, 0.42, 0.26, "#b77844");
  roundTop(H, n, 1.09, 1.09, lattice, 0.3);
}
function chicken(H, n) {
  band(H, n, 0, 0.15, -0.04, 0.43, 0.39, 0.24, "#9b512f", 1, 1.28);
  band(H, n, 0, 0.32, -0.04, 0.29, 0.43, 0.15, "#c87540", 1, 1.28);
  roundTop(H, n, 0.61, 0.78, roastSkin, 0.4, 0, -0.04);
  for (const s of [-1, 1]) {
    const drum = group();
    n.add(drum);
    drum.position.set(s * 0.34, 0.12, 0.3);
    drum.rotation.y = s * 0.58;
    band(H, drum, 0, 0.055, 0, 0.19, 0.18, 0.17, "#d2914e", 1, 1.46, 7);
    foldedSolid(H, drum, [0, 0.08, 0.28], ["box", 0.093, 0.095, 0.24], bone);
    band(H, drum, 0, 0.08, 0.39, 0.085, 0.09, 0.11, bone, 1.45, 0.85, 6);
  }
  herb(H, n, -0.47, -0.3, 0.06);
  herb(H, n, 0.18, -0.44, 0.055, 0.82);
}
function fruit(H, n) {
  band(H, n, 0, 0.1, 0, 0.49, 0.38, 0.16, "#ae7c52", 1, 1.16, 8);
  for (const [i, [x, z]] of [
    [-0.22, 0.17],
    [0.09, 0.25],
    [0.28, -0.04],
    [-0.13, -0.23],
    [0.02, -0.04],
  ].entries()) {
    const y = i === 4 ? 0.38 : 0.22;
    band(
      H,
      n,
      x,
      y,
      z,
      0.17,
      0.13,
      0.22,
      i % 2 ? "#b24b45" : "#c65741",
      1,
      1,
      7,
    );
    roundTop(H, n, 0.34, 0.34, apple, y + 0.12, x, z);
    foldedSolid(H, n, [x, y + 0.17, z], ["box", 0.04, 0.08, 0.05], "#73533e");
  }
  herb(H, n, 0.08, -0.08, 0.52, 0.85);
}
function cake(H, n) {
  const boundary = [
    [-0.44, -0.45],
    [0.48, -0.45],
    [0.22, 0.57],
    [-0.07, 0.62],
  ];
  // Layered fronts stay visible below the jam and cream icing.
  const outline = boundary.map(([x, z]) => [x, -z]);
  for (const [y, col] of [
    [0.065, "#ac7051"],
    [0.15, "#ffe4bb"],
    [0.21, berry],
    [0.28, "#bd8257"],
    [0.34, "#f6cfab"],
  ]) {
    const m = card(H, n, outline, pigment(col), {
      pitch: -Math.PI / 2,
      y,
      thickness: 0.078,
    });
    m.castShadow = true;
  }
  top(H, n, outline, icing, 0.397);
}
function cheeseAndGrapes(H, n) {
  const rind = [
    [-0.52, -0.26],
    [0.2, -0.35],
    [-0.27, 0.5],
  ];
  card(H, n, rind, pigment("#c7904d"), {
    pitch: -Math.PI / 2,
    y: 0.12,
    thickness: 0.23,
  });
  top(H, n, rind, cheese, 0.255);
  for (const [i, [x, z]] of [
    [0.15, 0.3],
    [0.32, 0.32],
    [0.22, 0.12],
    [0.41, 0.13],
    [0.3, -0.04],
    [0.47, -0.02],
    [0.35, -0.18],
  ].entries()) {
    band(
      H,
      n,
      x,
      0.13 + (i % 2) * 0.042,
      z,
      0.115,
      0.1,
      0.18,
      i % 3 ? "#734365" : "#965574",
      1,
      1,
      7,
    );
  }
  herb(H, n, 0.16, -0.17, 0.27, 0.68);
}
const mashPrint = print("#efd492", [
  [
    "#fff0c4",
    (g) => {
      bar(g, 0.17, 0.43, 0.5, 0.62, 0.07);
      bar(g, 0.45, 0.35, 0.78, 0.51, 0.07);
    },
  ],
  [
    leaf,
    (g) => {
      dot(g, 0.57, 0.63, 0.055);
      dot(g, 0.72, 0.61, 0.035);
    },
  ],
]);
function vegetables(H, n) {
  band(H, n, 0, 0.11, 0, 0.5, 0.34, 0.2, "#71958b", 1, 1.13);
  roundTop(H, n, 0.85, 0.96, mashPrint, 0.24);
  for (const [i, [x, z]] of [
    [-0.28, 0.18],
    [-0.18, 0.26],
    [0.09, 0.26],
    [0.23, 0.16],
  ].entries()) {
    const carrot = band(
      H,
      n,
      x,
      0.31,
      z,
      0.092,
      0.03,
      0.31,
      "#d8833b",
      1,
      1,
      6,
    );
    carrot.rotation.x = 0.99;
    carrot.rotation.z = i * 0.37;
  }
  herb(H, n, -0.13, -0.17, 0.27, 0.63);
}

function pieSlice(H, n) {
  const cut = [
    [-0.41, -0.31],
    [0.48, -0.29],
    [-0.23, 0.5],
  ];
  card(H, n, cut, pigment("#bf8053"), {
    pitch: -Math.PI / 2,
    y: 0.11,
    thickness: 0.21,
  });
  top(H, n, cut, lattice, 0.24);
}
function drumstick(H, n) {
  const leg = band(
    H,
    n,
    0,
    0.13,
    -0.08,
    0.28,
    0.23,
    0.23,
    "#c47b48",
    1,
    1.36,
    7,
  );
  leg.rotation.y = 0.22;
  foldedSolid(H, n, [0, 0.13, 0.35], ["box", 0.115, 0.11, 0.3], bone);
  band(H, n, 0, 0.14, 0.5, 0.108, 0.1, 0.13, bone, 1.4, 1, 7);
  herb(H, n, -0.3, -0.23, 0.052, 0.55);
}
function oneApple(H, n) {
  band(H, n, 0, 0.22, 0, 0.29, 0.2, 0.31, "#bc5144", 1, 1, 8);
  roundTop(H, n, 0.58, 0.58, apple, 0.38);
  foldedSolid(H, n, [0, 0.43, 0], ["box", 0.05, 0.13, 0.05], "#72513a");
  herb(H, n, 0, 0, 0.43, 0.5);
}
const recipes = [
  ["南瓜格纹派", pie, pieSlice],
  ["香草烤鸡", chicken, drumstick],
  ["红苹果果篮", fruit, oneApple],
  ["莓果夹层蛋糕", cake],
  ["奶酪与葡萄", cheeseAndGrapes],
  ["胡萝卜土豆泥", vegetables],
];
export const menuSize = recipes.length;
const kitchens = new WeakMap();
function dishModel(H, cook) {
  let kitchen = kitchens.get(H);
  if (!kitchen) {
    kitchen = new Map();
    kitchens.set(H, kitchen);
  }
  if (!kitchen.has(cook)) {
    const dish = group();
    cook(H, dish);
    kitchen.set(cook, dish);
  }
  return kitchen.get(cook).clone();
}
export function serve(H, parent, index, x, y, z, scale, course) {
  const [name, platter, individual = platter] = recipes[index % recipes.length];
  const portion = dishModel(H, course === "分餐" ? individual : platter);
  portion.name = name;
  portion.userData.course = course;
  portion.position.set(x, y, z);
  portion.scale.setScalar(scale);
  parent.add(portion);
  return portion;
}
function afternoonTea(H, n) {
  const gold = "#c99955",
    china = "#f2dbaf";
  band(H, n, 0, 0.09, 0, 0.2, 0.27, 0.15, gold);
  band(H, n, 0, 0.48, 0, 0.055, 0.06, 0.85, gold, 1, 1, 6);
  for (const [level, y] of [0.26, 0.77].entries()) {
    const r = level ? 0.36 : 0.56;
    band(H, n, 0, y, 0, r, r * 0.85, 0.065, gold);
    band(H, n, 0, y + 0.045, 0, r * 0.95, r * 0.96, 0.035, china);
    const count = level ? 2 : 4;
    for (let i = 0; i < count; i++) {
      const a = (2 * Math.PI * i) / count + 0.5,
        x = Math.cos(a) * r * 0.56,
        z = Math.sin(a) * r * 0.56;
      band(H, n, x, y + 0.12, z, 0.12, 0.135, 0.11, "#ca874f");
      band(H, n, x, y + 0.197, z, 0.12, 0.12, 0.045, "#fff0ca");
      band(
        H,
        n,
        x,
        y + 0.237,
        z,
        0.087,
        0.113,
        0.055,
        level ? berry : "#dcaa67",
      );
    }
  }
  band(H, n, 0, 1.0, 0, 0.1, 0.06, 0.12, gold, 1, 1, 6);
}
export function serveTeaStand(H, parent, y, z) {
  const stand = dishModel(H, afternoonTea);
  stand.name = "双层司康点心架";
  stand.userData.course = "公盘";
  stand.position.set(0, y, z);
  parent.add(stand);
}

// Cups, servings and place settings are fixed relative to their folding table. Keep every
// guest's articulated head and sleeves in their own hierarchy and batch the static repeats.
export function batchPlaceSettings(table) {
  table.updateWorldMatrix(true, true);
  const byShape = new Map(),
    local = new Matrix4().copy(table.matrixWorld).invert();
  function collect(o) {
    if (o.userData.guest) return;
    if (o.isMesh && !o.children.length) {
      const materials = Array.isArray(o.material) ? o.material : [o.material];
      const key = [
        o.geometry.id,
        ...materials.map((m) => m.id),
        o.castShadow,
        o.receiveShadow,
      ].join("/");
      if (!byShape.has(key)) byShape.set(key, []);
      byShape.get(key).push(o);
    } else for (const child of o.children) collect(child);
  }
  collect(table);
  for (const meshes of byShape.values()) {
    if (meshes.length < 3) continue;
    const first = meshes[0],
      batch = new InstancedMesh(first.geometry, first.material, meshes.length),
      matrix = new Matrix4();
    batch.castShadow = first.castShadow;
    batch.receiveShadow = first.receiveShadow;
    meshes.forEach((mesh, i) => {
      batch.setMatrixAt(i, matrix.multiplyMatrices(local, mesh.matrixWorld));
      mesh.removeFromParent();
    });
    batch.computeBoundingSphere();
    table.add(batch);
  }
}
