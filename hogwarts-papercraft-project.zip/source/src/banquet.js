import { addStudent, addProfessor, faculty } from "./diners.js";
import { serve, menuSize, batchPlaceSettings, serveTeaStand } from "./feast.js";
import {
  card,
  group,
  rect,
  oval,
  poly,
  dot,
  bar,
  print,
  foldedSolid,
  pigment,
} from "./paper.js";
import { houses, parchment, brass, oak, star } from "./houses.js";

const wedge = (g, x, y, w, h) =>
  poly(g, [
    [x, y + h],
    [x + w, y],
    [x, y - h],
    [x - w, y],
  ]);
const textile = (h) =>
  print(h.color, [
    [
      h.light,
      (g) => {
        for (const x of [0.1, 0.88]) g.fillRect(x, 0, 0.025, 1);
        for (let t = 0; t < 10; t++) wedge(g, 0.5, (t + 0.5) / 10, 0.22, 0.017);
      },
    ],
  ]);
const board = print(oak, [
  [
    "#ae8056",
    (g) => {
      for (const y of [0.02, 0.17, 0.5, 0.81, 0.98]) g.fillRect(0, y, 1, 0.012);
      for (let i = 0; i < 5; i++)
        g.fillRect(0.1 + (i % 2) * 0.43, 0.12 + i * 0.16, 0.26, 0.01);
    },
  ],
]);
const crockery = print("#dbbf85", [
  ["#faf0cd", (g) => dot(g, 0.5, 0.5, 0.48, 0.47)],
  ["#b39153", (g) => dot(g, 0.5, 0.5, 0.39, 0.38)],
  ["#eddbaf", (g) => dot(g, 0.5, 0.5, 0.355, 0.35)],
]);
function flatCard(H, parent, w, d, paint, x, y, z) {
  return card(H, parent, rect(w, d), paint, {
    x,
    y,
    z: z + d / 2,
    pitch: -Math.PI / 2,
  });
}
function tableBoard(H, parent, w, d, height) {
  foldedSolid(H, parent, [0, height - 0.11, 0], ["box", w, 0.22, d], oak);
  flatCard(H, parent, w, d, board, 0, height + 0.035, 0);
  const trestles = d > 18 ? [-0.42, -0.14, 0.14, 0.42] : [-0.39, 0.39];
  for (const position of trestles)
    for (const x of [-w * 0.32, w * 0.32]) {
      foldedSolid(
        H,
        parent,
        [x, height / 2 - 0.13, position * d],
        ["cone", 0.15, 0.25, height - 0.26, 4],
        "#75503e",
      );
    }
}
function cup(H, n, x, y, z) {
  foldedSolid(H, n, [x, y + 0.045, z], ["cone", 0.125, 0.17, 0.09, 7], brass);
  foldedSolid(H, n, [x, y + 0.15, z], ["cone", 0.06, 0.065, 0.15, 6], brass);
  foldedSolid(
    H,
    n,
    [x, y + 0.32, z],
    ["cone", 0.185, 0.065, 0.25, 7],
    "#e5b96b",
  );
  foldedSolid(
    H,
    n,
    [x, y + 0.451, z],
    ["cone", 0.148, 0.147, 0.016, 7],
    "#653732",
  );
}
const loaf = print("#ce854a", [
  [
    "#f4cf88",
    (g) => {
      for (const x of [0.18, 0.42, 0.66])
        bar(g, x, 0.42, x + 0.11, 0.76, 0.052);
    },
  ],
]);
const pudding = print("#713e35", [
  [
    parchment,
    (g) =>
      poly(g, [
        [0, 0.57],
        [0.12, 0.66],
        [0.2, 0.54],
        [0.28, 0.73],
        [0.41, 0.62],
        [0.5, 0.72],
        [0.65, 0.53],
        [0.74, 0.7],
        [0.88, 0.62],
        [1, 0.67],
        [1, 1],
        [0, 1],
      ]),
  ],
  [
    "#9d3842",
    (g) => {
      dot(g, 0.46, 0.87, 0.07);
      dot(g, 0.57, 0.84, 0.06);
    },
  ],
]);
function platter(H, n, z, index) {
  const y = 1.64;
  card(H, n, oval(0.93, 1.2), crockery, {
    z: z + 0.57,
    y,
    pitch: -Math.PI / 2,
  });
  if (index >= 2) {
    serve(H, n, index - 2, 0, y + 0.052, z, 1, "公盘");
    return;
  }
  const pts =
    index % 2
      ? [
          [-0.4, 0],
          [0.4, 0],
          [0.39, 0.15],
          [0.26, 0.37],
          [0.05, 0.41],
          [-0.22, 0.36],
          [-0.4, 0.19],
        ]
      : [
          [-0.45, 0],
          [0.45, 0],
          [0.42, 0.16],
          [0.26, 0.3],
          [-0.17, 0.35],
          [-0.4, 0.23],
        ];
  card(H, n, pts, index % 2 ? pudding : loaf, {
    z: z + 0.08,
    y: y + 0.05,
    yaw: 0.3,
  });
}
export function longTable(H, house, d) {
  const n = group(),
    w = 2.9,
    h = 1.49;
  tableBoard(H, n, w, d, h);
  flatCard(H, n, 0.85, d + 0.025, textile(house), 0, h + 0.09, 0);
  for (const end of [-1, 1])
    card(
      H,
      n,
      [
        [-0.425, 0],
        [0, -0.24],
        [0.425, 0],
        [0.425, 0.6],
        [-0.425, 0.6],
      ],
      textile(house),
      { y: h - 0.54, z: end * (d / 2 + 0.04) },
    );
  const houseIndex = houses.indexOf(house);
  const seatsPerSide = Math.floor(d / 2.45);
  // Four pairs per house, grouped with occasional empty bench space between conversations.
  const seatsBySide = [
    [0, 3, 5, 8],
    [1, 4, 6, 9],
  ];
  for (const side of [-1, 1]) {
    const b = group();
    b.position.x = side * 2.12;
    n.add(b);
    tableBoard(H, b, 0.6, d - 0.45, 0.69);
    for (let i = 0; i < seatsPerSide; i++) {
      const z = ((i + 0.5 - seatsPerSide / 2) * d) / seatsPerSide;
      card(H, n, oval(0.72, 0.72), crockery, {
        x: side * 0.97,
        y: h + 0.093,
        z: z + 0.36,
        pitch: -Math.PI / 2,
      });
      cup(H, n, side * 1.05, h + 0.1, z - 0.61);
      const diners = seatsBySide[side > 0 ? 1 : 0];
      const occupied = diners.includes((i + houseIndex) % seatsPerSide);
      if (occupied) addStudent(H, n, house, houseIndex, side, i, z);
      if (occupied || (i + houseIndex + (side > 0 ? 1 : 0)) % 3 === 0) {
        const dish = (i + houseIndex * 2 + (side > 0 ? 3 : 0)) % menuSize;
        serve(H, n, dish, side * 0.97, h + 0.15, z, 0.54, "分餐");
      }
    }
  }
  const platters = Math.floor(d / 3.75);
  for (let j = 0; j < platters; j++)
    platter(
      H,
      n,
      ((j + 0.5 - platters / 2) * d) / platters,
      (j + houseIndex * 2) % (menuSize + 2),
    );
  const jugZ = house.x < 0 ? 2.05 : -2.15;
  foldedSolid(
    H,
    n,
    [0, h + 0.37, jugZ],
    ["cone", 0.29, 0.36, 0.54, 8],
    "#b68d59",
  );
  foldedSolid(
    H,
    n,
    [0, h + 0.7, jugZ],
    ["cone", 0.24, 0.17, 0.19, 8],
    "#ebc987",
  );
  card(
    H,
    n,
    [
      [0, 0],
      [0.28, 0.05],
      [0.42, 0.21],
      [0.41, 0.44],
      [0.22, 0.51],
      [0.19, 0.44],
      [0.32, 0.38],
      [0.31, 0.23],
      [0.2, 0.16],
      [0, 0.13],
    ],
    pigment(brass),
    { x: 0.15, y: h + 0.2, z: jugZ },
  );
  for (let j = 1; j < platters; j += 2) {
    const between = ((j - platters / 2) * d) / platters;
    if (Math.abs(Math.abs(between) - Math.abs(jugZ)) < 1.15) continue;
    if (j === (houseIndex % 2 ? 1 : 5)) {
      serveTeaStand(H, n, h + 0.14, between);
      continue;
    }
    const dish = serve(
      H,
      n,
      (j + houseIndex + 1) % menuSize,
      0,
      h + 0.18,
      between,
      0.77,
      "公盘",
    );
    dish.rotation.y = houseIndex * 0.39;
  }
  const pumpkinZ = -jugZ;
  foldedSolid(
    H,
    n,
    [0, h + 0.29, pumpkinZ],
    ["cone", 0.32, 0.36, 0.32, 8],
    "#cc753d",
  );
  foldedSolid(
    H,
    n,
    [0, h + 0.53, pumpkinZ],
    ["cone", 0.17, 0.32, 0.16, 8],
    "#e79c49",
  );
  foldedSolid(
    H,
    n,
    [0, h + 0.66, pumpkinZ],
    ["cone", 0.045, 0.07, 0.14, 5],
    "#76604a",
  );
  batchPlaceSettings(n);
  return n;
}
const carving = print("#764635", [
  [
    brass,
    (g) => {
      g.fillRect(0.06, 0.1, 0.88, 0.045);
      g.fillRect(0.1, 0.7, 0.8, 0.032);
      wedge(g, 0.5, 0.48, 0.16, 0.18);
    },
  ],
]);
const velvet = print("#8e3c4c", [
  [
    brass,
    (g) => {
      wedge(g, 0.5, 0.55, 0.18, 0.18);
      g.fillRect(0.08, 0.08, 0.84, 0.04);
    },
  ],
]);
export function highTable(H, width) {
  const n = group();
  tableBoard(H, n, width, 1.7, 1.52);
  const front = print("#653741", [
    [
      brass,
      (g) => {
        for (let k = 0; k < 7; k++) {
          const x = (k + 0.5) / 7;
          wedge(g, x, 0.47, 0.04, 0.22);
          star(g, x, 0.48, 0.036);
        }
        g.fillRect(0, 0.12, 1, 0.036);
        g.fillRect(0, 0.83, 1, 0.036);
      },
    ],
  ]);
  card(H, n, rect(width + 0.05, 0.86), front, { y: 0.68, z: 0.9 });
  const professorSeats = [-3, -1, 0, 1, 3];
  for (let k = -3; k <= 3; k++) {
    const x = (k * (width - 2.2)) / 6;
    const seat = group();
    seat.position.set(x, 0, -1.72);
    n.add(seat);
    const h = x === 0 ? 3.95 : 3.02;
    card(
      H,
      seat,
      [
        [-0.69, 0],
        [0.69, 0],
        [0.69, h - 0.36],
        [0.43, h - 0.55],
        [0, h],
        [-0.43, h - 0.55],
        [-0.69, h - 0.36],
      ],
      carving,
      { z: -0.32 },
    );
    card(
      H,
      seat,
      [
        [-0.48, 0],
        [0.48, 0],
        [0.46, h * 0.39],
        [0, h * 0.52],
        [-0.46, h * 0.39],
      ],
      velvet,
      { y: 1.08, z: -0.2 },
    );
    foldedSolid(H, seat, [0, 0.78, 0.1], ["box", 1.35, 0.2, 1.1], oak);
    const staffIndex = professorSeats.indexOf(k);
    if (staffIndex !== -1)
      addProfessor(H, seat, faculty[staffIndex], staffIndex);
    cup(H, n, x + 0.57, 1.6, -0.18);
    card(H, n, oval(0.78, 0.78), crockery, {
      x: x - 0.05,
      y: 1.63,
      z: 0.5,
      pitch: -Math.PI / 2,
    });
    serve(H, n, (k + 3) % menuSize, x - 0.05, 1.69, 0.11, 0.56, "分餐");
    if (k < 3 && k % 2 !== 0) {
      const px = x + (width - 2.2) / 12;
      card(H, n, oval(0.93, 1.1), crockery, {
        x: px,
        y: 1.62,
        z: 0.52,
        pitch: -Math.PI / 2,
      });
      serve(H, n, (k + 5) % menuSize, px, 1.68, -0.03, 0.86, "公盘");
    }
  }
  batchPlaceSettings(n);
  return n;
}
export function sortingHat(H) {
  const n = group();
  const leather = print("#714531", [
    [
      "#b48657",
      (g) => {
        bar(g, 0.17, 0.32, 0.58, 0.21, 0.065);
        bar(g, 0.4, 0.59, 0.68, 0.72, 0.075);
      },
    ],
    [
      "#362b33",
      (g) => {
        poly(g, [
          [0.24, 0.43],
          [0.45, 0.4],
          [0.38, 0.35],
          [0.27, 0.37],
        ]);
        poly(g, [
          [0.49, 0.41],
          [0.69, 0.47],
          [0.62, 0.38],
        ]);
        poly(g, [
          [0.33, 0.21],
          [0.51, 0.26],
          [0.63, 0.23],
          [0.47, 0.16],
        ]);
      },
    ],
  ]);
  foldedSolid(H, n, [0, 0.53, 0], ["cone", 0.18, 0.28, 0.91, 4], oak);
  foldedSolid(H, n, [0, 1.03, 0], ["cone", 0.78, 0.75, 0.22, 8], oak);
  card(H, n, oval(2.16, 1.46), pigment("#8e6244"), {
    y: 1.18,
    z: 0.73,
    pitch: -Math.PI / 2,
  });
  card(
    H,
    n,
    [
      [-0.78, 0],
      [0.73, 0],
      [0.55, 0.37],
      [0.33, 0.85],
      [0.35, 1.38],
      [0.78, 1.63],
      [0.31, 1.65],
      [-0.11, 1.43],
      [-0.26, 0.95],
      [-0.57, 0.54],
    ],
    leather,
    { y: 1.2, z: 0.075, thickness: 0.16 },
  );
  return n;
}
const flameGold = print("#ffbb4f"),
  flameCore = print("#fff1bb"),
  wax = print("#f0d9a6", [
    [
      parchment,
      (g) => {
        g.fillRect(0.16, 0.08, 0.13, 0.84);
        g.fillRect(0.52, 0.66, 0.09, 0.32);
      },
    ],
  ]);
export function candle(H, height) {
  const n = group();
  const shape = [
    [-0.13, 0],
    [0.13, 0],
    [0.13, height],
    [0.035, height - 0.045],
    [-0.045, height + 0.035],
    [-0.13, height],
  ];
  card(H, n, shape, wax, { thickness: 0.1 });
  card(
    H,
    n,
    [
      [0, 0],
      [0.12, 0.14],
      [0.11, 0.32],
      [-0.015, 0.54],
      [-0.09, 0.3],
      [-0.13, 0.15],
    ],
    flameGold,
    { y: height + 0.04 },
  );
  card(
    H,
    n,
    [
      [0, 0],
      [0.06, 0.1],
      [0.005, 0.29],
      [-0.049, 0.13],
    ],
    flameCore,
    { y: height + 0.08, z: 0.078, thickness: 0.035 },
  );
  return n;
}

export function owlLectern(H) {
  const n = group(),
    bronze = print("#ba8a47", [
      [
        "#e7c684",
        (g) => {
          for (let i = 0; i < 5; i++)
            bar(g, i * 0.18, 0.25, 0.12 + i * 0.16, 0.72, 0.026);
        },
      ],
    ]);
  foldedSolid(H, n, [0, 0.16, 0], ["cone", 0.65, 0.88, 0.32, 6], "#8e6b46");
  foldedSolid(H, n, [0, 0.83, 0], ["cone", 0.25, 0.38, 1.22, 6], brass);
  const wing = [
    [-1.5, 1.0],
    [-1.31, 0.62],
    [-1.43, 0.68],
    [-1.05, 0.23],
    [-1.12, 0.25],
    [-0.69, 0.06],
    [-0.13, 0],
    [0.01, 0.5],
    [-0.48, 0.65],
    [-0.93, 0.69],
  ];
  card(H, n, wing, bronze, { y: 1.27, z: 0.11 });
  card(H, n, wing.map(([x, y]) => [-x, y]).reverse(), bronze, {
    y: 1.27,
    z: 0.11,
  });
  const owlFace = print("#bf934f", [
    [
      "#eacf95",
      (g) => {
        dot(g, 0.34, 0.66, 0.19, 0.15);
        dot(g, 0.65, 0.66, 0.19, 0.15);
      },
    ],
    [
      "#453341",
      (g) => {
        dot(g, 0.35, 0.68, 0.08, 0.075);
        dot(g, 0.65, 0.68, 0.08, 0.075);
        poly(g, [
          [0.43, 0.62],
          [0.58, 0.62],
          [0.5, 0.48],
        ]);
      },
    ],
  ]);
  card(
    H,
    n,
    [
      [-0.44, 1.04],
      [-0.56, 1.31],
      [-0.26, 1.2],
      [0, 1.29],
      [0.3, 1.2],
      [0.53, 1.33],
      [0.44, 0.98],
      [0.45, 0.49],
      [0.26, 0.15],
      [0, 0],
      [-0.33, 0.2],
      [-0.43, 0.55],
    ],
    owlFace,
    { y: 1.18, z: 0.29 },
  );
  const writing = print("#f5e3bd", [
    [
      "#876c5a",
      (g) => {
        for (let j = 0; j < 5; j++) {
          g.fillRect(0.16, 0.2 + j * 0.13, 0.61 - (j % 3) * 0.08, 0.028);
        }
      },
    ],
  ]);
  for (const s of [-1, 1]) {
    const leaf = group();
    leaf.position.set(s * 0.41, 2.6, -0.06);
    leaf.rotation.z = -s * 0.1;
    leaf.rotation.x = -0.88;
    n.add(leaf);
    card(H, leaf, rect(0.82, 0.84), pigment("#72393c"), { thickness: 0.08 });
    card(H, leaf, rect(0.75, 0.78), writing, { z: 0.07, y: 0.03 });
  }
  return n;
}
