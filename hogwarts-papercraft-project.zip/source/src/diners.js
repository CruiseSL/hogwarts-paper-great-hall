import {
  card,
  group,
  rect,
  oval,
  poly,
  dot,
  bar,
  print,
  pigment,
  foldedSolid,
} from "./paper.js";
import { brass, parchment } from "./houses.js";

const ink = "#312b38";
const students = [
  { skin: "#e8ab83", hair: "#a85033", cut: "crop", freckles: true },
  { skin: "#d8a37f", hair: "#5c4138", cut: "curls" },
  { skin: "#935f4d", hair: "#332c33", cut: "curls" },
  { skin: "#eed0a6", hair: "#c39a62", cut: "part" },
  { skin: "#ad7960", hair: "#43333b", cut: "bob", glasses: true },
  { skin: "#e3b095", hair: "#302a34", cut: "bob" },
  { skin: "#b78769", hair: "#5b3c37", cut: "crop" },
  { skin: "#f0c3a3", hair: "#cb9867", cut: "bob", freckles: true },
];
export const faculty = [
  {
    name: "天文课教授",
    skin: "#925f4e",
    hair: "#4a353c",
    cut: "curls",
    cloth: "#4c4169",
    trim: "#c8af7a",
  },
  {
    name: "麦格教授",
    skin: "#dfb296",
    hair: "#514550",
    cut: "part",
    cloth: "#245749",
    trim: "#deb56b",
    hat: "witch",
    glasses: true,
  },
  {
    name: "邓布利多",
    skin: "#e2b7a0",
    hair: "#d4c6b9",
    cut: "bob",
    cloth: "#69536f",
    trim: "#e1bd77",
    hat: "cap",
    beard: true,
    glasses: true,
  },
  {
    name: "斯内普教授",
    skin: "#dfbdab",
    hair: "#322e3b",
    cut: "bob",
    cloth: "#353341",
    trim: "#786b76",
  },
  {
    name: "草药课教授",
    skin: "#cf9c77",
    hair: "#76624d",
    cut: "curls",
    cloth: "#716344",
    trim: "#e1c293",
    hat: "soft",
  },
];

const hairCuts = {
  crop: [
    [-0.55, 0.1],
    [-0.58, 0.32],
    [-0.49, 0.51],
    [-0.3, 0.58],
    [-0.12, 0.52],
    [0.03, 0.66],
    [0.2, 0.55],
    [0.36, 0.56],
    [0.52, 0.42],
    [0.57, 0.16],
    [0.46, -0.01],
    [0.4, 0.22],
    [0.21, 0.14],
    [0.25, 0.28],
    [0.02, 0.18],
    [-0.16, 0.08],
    [-0.14, 0.22],
    [-0.34, 0.12],
    [-0.42, -0.07],
  ],
  part: [
    [-0.55, 0.08],
    [-0.52, 0.38],
    [-0.36, 0.52],
    [0.03, 0.59],
    [0.31, 0.52],
    [0.52, 0.32],
    [0.55, 0.04],
    [0.45, -0.11],
    [0.4, 0.15],
    [0.23, 0.21],
    [0.12, 0.34],
    [-0.04, 0.23],
    [-0.22, 0.16],
    [-0.39, 0.09],
    [-0.49, -0.11],
  ],
  bob: [
    [-0.56, -0.38],
    [-0.6, 0.15],
    [-0.53, 0.43],
    [-0.31, 0.56],
    [0.11, 0.59],
    [0.37, 0.51],
    [0.55, 0.29],
    [0.58, -0.32],
    [0.39, -0.43],
    [0.4, 0.07],
    [0.25, 0.21],
    [0.09, 0.26],
    [-0.11, 0.17],
    [-0.3, 0.1],
    [-0.4, -0.02],
    [-0.37, -0.4],
  ],
  curls: [
    [-0.57, -0.1],
    [-0.65, 0.02],
    [-0.6, 0.15],
    [-0.67, 0.27],
    [-0.54, 0.39],
    [-0.5, 0.51],
    [-0.33, 0.52],
    [-0.22, 0.64],
    [-0.06, 0.59],
    [0.09, 0.65],
    [0.23, 0.58],
    [0.41, 0.59],
    [0.48, 0.46],
    [0.59, 0.43],
    [0.65, 0.28],
    [0.59, 0.16],
    [0.63, 0.04],
    [0.51, -0.1],
    [0.43, -0.02],
    [0.39, 0.15],
    [0.23, 0.12],
    [0.13, 0.22],
    [-0.06, 0.17],
    [-0.18, 0.24],
    [-0.31, 0.14],
    [-0.42, 0.16],
    [-0.48, 0.01],
  ],
};
const facePaints = new Map(),
  robePaints = new Map();
function portrait(person) {
  if (facePaints.has(person)) return facePaints.get(person);
  const paint = (P) => {
    P.fill(person.skin);
    P.draw((g) => {
      g.translate(P.box.x0, P.box.y0);
      g.scale(P.box.w, P.box.h);
      g.fillStyle = ink;
      dot(g, 0.32, 0.5, 0.044, 0.058);
      dot(g, 0.69, 0.5, 0.044, 0.058);
      bar(g, 0.25, 0.62, 0.38, 0.64, 0.025);
      bar(g, 0.63, 0.64, 0.75, 0.61, 0.025);
      g.fillStyle = "#9c5c53";
      poly(g, [
        [0.49, 0.49],
        [0.44, 0.35],
        [0.54, 0.35],
      ]);
      bar(g, 0.44, 0.23, 0.55, 0.22, 0.021);
      if (person.glasses) {
        g.strokeStyle = ink;
        g.lineWidth = 0.035;
        for (const x of [0.32, 0.68]) {
          g.beginPath();
          g.ellipse(x, 0.51, 0.15, 0.13, 0, 0, Math.PI * 2);
          g.stroke();
        }
        bar(g, 0.46, 0.52, 0.54, 0.52, 0.028);
      }
      if (person.freckles) {
        for (const x of [0.18, 0.23, 0.28, 0.72, 0.77, 0.82])
          dot(g, x, 0.39 + 0.015 * Math.cos(x * 28), 0.012);
      }
    });
  };
  facePaints.set(person, paint);
  return paint;
}
function uniform(colors, professor) {
  const key = colors.color + colors.light + professor;
  if (robePaints.has(key)) return robePaints.get(key);
  const paint = print(professor ? colors.color : "#403a49", [
    [
      professor ? colors.light : "#84757b",
      (g) => {
        poly(g, [
          [0.08, 0.03],
          [0.19, 0.18],
          [0.26, 0.89],
          [0.13, 0.74],
        ]);
        bar(g, 0.72, 0.77, 0.84, 0.11, 0.027);
      },
    ],
    [
      parchment,
      (g) =>
        poly(g, [
          [0.27, 0.97],
          [0.73, 0.97],
          [0.52, 0.57],
        ]),
    ],
    [
      colors.color,
      (g) => {
        poly(g, [
          [0.21, 0.99],
          [0.73, 0.99],
          [0.65, 0.83],
          [0.33, 0.78],
        ]);
        poly(g, [
          [0.35, 0.83],
          [0.5, 0.81],
          [0.39, 0.28],
          [0.23, 0.32],
        ]);
      },
    ],
    [
      colors.light,
      (g) => {
        for (const y of [0.39, 0.54, 0.69])
          bar(
            g,
            0.245 + (y - 0.39) * 0.23,
            y,
            0.416 + (y - 0.39) * 0.23,
            y - 0.04,
            0.055,
          );
        poly(g, [
          [0.69, 0.68],
          [0.83, 0.68],
          [0.81, 0.54],
          [0.75, 0.5],
          [0.69, 0.55],
        ]);
      },
    ],
  ]);
  robePaints.set(key, paint);
  return paint;
}
const coat = [
  [-0.53, 0],
  [0.55, 0],
  [0.48, 0.88],
  [0.36, 1.14],
  [-0.36, 1.14],
  [-0.5, 0.88],
];
function headwear(H, head, p) {
  if (!p.hat) return;
  const cloth = pigment(p.cloth);
  if (p.hat === "witch") {
    card(
      H,
      head,
      [
        [-0.78, 0],
        [0.71, 0.02],
        [0.51, 0.15],
        [0.24, 0.22],
        [0.04, 0.75],
        [0.14, 1.03],
        [-0.12, 0.94],
        [-0.28, 0.64],
        [-0.39, 0.23],
      ],
      cloth,
      { y: 0.9, z: 0.26 },
    );
  } else {
    const peak = p.hat === "cap" ? 0.36 : 0.2;
    foldedSolid(
      H,
      head,
      [0, 1.04, 0],
      ["cone", 0.31, 0.55, peak, 8],
      p.cloth,
    ).scale.z = 0.67;
    foldedSolid(
      H,
      head,
      [0, 0.94, 0],
      ["cone", 0.55, 0.55, 0.09, 8],
      p.trim,
    ).scale.z = 0.7;
  }
}
function diner(H, person, colors, gesture) {
  const n = group(),
    torso = group(),
    head = group(),
    professor = !!person.cloth;
  n.add(torso);
  torso.add(head);
  head.position.set(0, 0.98, 0);
  for (const x of [-0.24, 0.24]) {
    foldedSolid(H, n, [x, -0.02, 0.21], ["box", 0.27, 0.23, 0.54], "#49404c");
    foldedSolid(H, n, [x, -0.32, 0.43], ["box", 0.24, 0.57, 0.22], ink);
    foldedSolid(H, n, [x, -0.59, 0.51], ["box", 0.31, 0.18, 0.4], ink);
  }
  const cloth = professor ? person.cloth : "#403a49";
  foldedSolid(
    H,
    torso,
    [0, 0.52, -0.02],
    ["cone", 0.46, 0.52, 1.04, 6],
    cloth,
  ).scale.z = 0.48;
  card(H, torso, coat, uniform(colors, professor), { z: 0.235 });

  foldedSolid(
    H,
    head,
    [0, 0.56, 0],
    ["cone", 0.49, 0.41, 0.7, 8],
    person.skin,
  ).scale.z = 0.58;
  card(H, head, oval(1.02, 1.1), portrait(person), {
    z: 0.31,
    thickness: 0.08,
  });
  foldedSolid(
    H,
    head,
    [0, 0.75, -0.075],
    ["cone", 0.46, 0.51, 0.53, 8],
    person.hair,
  ).scale.z = 0.58;
  card(H, head, hairCuts[person.cut], pigment(person.hair), {
    y: 0.66,
    z: 0.39,
  });
  if (person.beard) {
    card(
      H,
      head,
      [
        [-0.46, 0.54],
        [-0.28, 0.4],
        [-0.1, 0.45],
        [0.0, 0.4],
        [0.17, 0.46],
        [0.38, 0.52],
        [0.42, 0.24],
        [0.31, -0.1],
        [0.15, -0.25],
        [0.02, -0.46],
        [-0.18, -0.25],
        [-0.38, -0.03],
      ],
      pigment("#e2d5bf"),
      { z: 0.39 },
    );
  }
  headwear(H, head, person);
  const arm = group();
  torso.add(arm);
  arm.position.set(0.46, 0.86, 0.17);
  const sleeve = pigment(cloth);
  card(
    H,
    arm,
    [
      [-0.12, -0.48],
      [0.12, -0.48],
      [0.16, -0.12],
      [0.11, 0.05],
      [-0.1, 0.11],
      [-0.15, -0.02],
    ],
    sleeve,
  );
  card(H, arm, oval(0.25, 0.24), pigment(person.skin), { y: -0.59, z: 0.065 });
  arm.rotation.x =
    gesture === "toast" ? -1.57 : gesture === "serve" ? -1.16 : -0.45;
  if (gesture === "toast") {
    // The cup sits upright on the hand at the end of the bent sleeve.
    const goblet = group();
    arm.add(goblet);
    goblet.position.set(0, -0.56, 0.11);
    goblet.rotation.x = -arm.rotation.x;
    foldedSolid(H, goblet, [0, 0.08, 0], ["cone", 0.07, 0.065, 0.16, 6], brass);
    foldedSolid(
      H,
      goblet,
      [0, 0.25, 0],
      ["cone", 0.17, 0.07, 0.2, 7],
      "#dfb462",
    );
  }
  const resting = card(
    H,
    torso,
    [
      [-0.18, -0.52],
      [0.08, -0.55],
      [0.12, -0.3],
      [0.1, 0.04],
      [-0.08, 0.12],
      [-0.17, -0.05],
    ],
    sleeve,
    { x: -0.46, y: 0.8, z: 0.12, pitch: -0.74 },
  );
  card(H, resting, oval(0.22, 0.2), pigment(person.skin), {
    x: -0.07,
    y: -0.61,
    z: 0.06,
  });
  return { n, head, arm };
}
export function addStudent(H, table, house, houseIndex, side, seat, z) {
  const serial = seat + houseIndex * 3 + (side > 0 ? 2 : 0),
    style = students[serial % students.length];
  const gestures = ["listen", "serve", "toast", "listen", "serve"];
  const gesture = gestures[serial % gestures.length],
    { n, head, arm } = diner(H, style, house, gesture);
  n.name = house.name + "学生";
  n.userData.guest = "student";
  n.position.set(side * 2.12, 0.735, z);
  // Across-table conversation and turned neighbours leave the faces visible from the aisle.
  n.rotation.y = -side * (0.82 + (serial % 4) * 0.115);
  n.scale.setScalar(0.94 + (serial % 5) * 0.037);
  table.add(n);
  const yaw = side * 0.31 + ((serial % 3) - 1) * 0.12;
  head.rotation.y = yaw;
  if (gesture !== "listen") {
    const pitch = arm.rotation.x;
    H.onStep((t) => {
      const beat = Math.sin(t * (0.75 + (serial % 3) * 0.12) + serial * 1.47);
      head.rotation.y = yaw + beat * 0.095;
      arm.rotation.x = pitch + beat * (gesture === "toast" ? 0.085 : 0.035);
    });
  }
}
export function addProfessor(H, seat, person, index) {
  const { n, head } = diner(
    H,
    person,
    { color: person.cloth, light: person.trim },
    "listen",
  );
  n.name = person.name;
  n.userData.guest = "faculty";
  seat.add(n);
  n.position.set(0, 0.89, 0.2);
  n.scale.setScalar(1.11);
  const angle = ((index % 3) - 1) * 0.17;
  n.rotation.y = angle;
  H.onStep((t) => {
    head.rotation.y = 0.075 * Math.sin(t * 0.52 + index);
    head.rotation.z = 0.016 * Math.sin(t * 0.64 + index);
  });
}
