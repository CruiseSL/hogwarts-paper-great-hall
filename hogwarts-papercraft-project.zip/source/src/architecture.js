import { card, group, rect, oval, poly, dot, bar, print } from "./paper.js";
import {
  houses,
  midnight,
  parchment,
  brass,
  bannerPrint,
  star,
} from "./houses.js";

const stone = print("#9b8984", [
  [
    "#c0ad99",
    (g) => {
      for (let i = 1; i < 10; i++) g.fillRect(0, i / 10, 1, 0.011);
      for (let i = 0; i < 10; i++)
        for (let j = 0; j < 3; j++)
          g.fillRect((j + (i % 2) * 0.5) / 3, i / 10, 0.008, 0.1);
    },
  ],
]);
const darkStone = print("#685965"),
  gold = print(brass),
  sandstone = print("#baab93");
const skyPaint = print(midnight, [
  [
    "#394261",
    (g) => {
      for (let k = 0; k < 4; k++) {
        g.beginPath();
        g.moveTo(0, 0.18 + k * 0.17);
        g.bezierCurveTo(
          0.22,
          0.03 + k * 0.18,
          0.63,
          0.55 + k * 0.14,
          1,
          0.26 + k * 0.17,
        );
        g.lineWidth = 0.021;
        g.strokeStyle = "#444966";
        g.stroke();
      }
    },
  ],
  [
    "#c8ad80",
    (g) => {
      const pts = [
        [0.08, 0.42],
        [0.15, 0.6],
        [0.22, 0.51],
        [0.31, 0.72],
        [0.38, 0.65],
      ];
      for (let i = 1; i < pts.length; i++)
        bar(g, ...pts[i - 1], ...pts[i], 0.004);
      for (const [x, y] of pts) star(g, x, y, 0.027);
    },
  ],
  [
    "#f6daaf",
    (g) => {
      for (let i = 0; i < 91; i++) {
        const x = ((i * 47 + 13) % 101) / 101,
          y = ((i * 71 + 23) % 107) / 107;
        if (i % 6 === 0) star(g, x, y, 0.018);
        else dot(g, x, y, 0.0028, 0.0055);
      }
    },
  ],
]);
const arch = (w, h) => [
  [-w / 2, 0],
  [w / 2, 0],
  [w / 2, h * 0.58],
  [w * 0.46, h * 0.7],
  [w * 0.35, h * 0.8],
  [w * 0.17, h * 0.92],
  [0, h],
  [-w * 0.17, h * 0.92],
  [-w * 0.35, h * 0.8],
  [-w * 0.46, h * 0.7],
  [-w / 2, h * 0.58],
];
function glass(moon) {
  return print("#344564", [
    [
      "#546895",
      (g) => {
        for (let i = -5; i < 8; i++)
          poly(g, [
            [i * 0.18, 0],
            [i * 0.18 + 0.12, 0],
            [i * 0.18 + 0.93, 1],
            [i * 0.18 + 0.82, 1],
          ]);
      },
    ],
    [
      "#d5bc90",
      (g) => {
        for (let i = 0; i < 31; i++) {
          const x = ((31 * i + 10) % 89) / 89,
            y = ((53 * i + 15) % 83) / 83;
          star(g, x, y, 0.013 + (i % 4) * 0.003);
        }
        if (moon) dot(g, 0.51, 0.64, 0.115, 0.09);
      },
    ],
    [
      "#48567c",
      (g) => {
        if (moon) dot(g, 0.55, 0.667, 0.099, 0.079);
      },
    ],
    [
      "#212b42",
      (g) => {
        for (const x of [0.26, 0.5, 0.74])
          g.fillRect(x - 0.017, 0, 0.034, 0.58);
        for (const y of [0.17, 0.35]) g.fillRect(0, y, 1, 0.02);
        for (const x of [0.14, 0.38, 0.62, 0.86]) {
          bar(g, x - 0.12, 0.53, x, 0.72, 0.027);
          bar(g, x, 0.72, x + 0.12, 0.53, 0.027);
        }
        for (const s of [-1, 1]) bar(g, 0.5, 0.96, 0.5 + s * 0.35, 0.59, 0.024);
      },
    ],
    [
      "#c0a476",
      (g) => {
        for (const x of [0.26, 0.5, 0.74])
          g.fillRect(x - 0.024, 0.01, 0.011, 0.55);
        g.fillRect(0.04, 0.07, 0.92, 0.012);
      },
    ],
  ]);
}
const windowPrint = glass(false),
  moonPrint = glass(true);
function windowCard(
  H,
  parent,
  { x = 0, y = 0.8, z = 0.2, w, h, moon = false },
) {
  card(H, parent, arch(w, h), darkStone, { x, y, z });
  card(H, parent, arch(w * 0.93, h * 0.94), sandstone, {
    x,
    y: y + 0.16,
    z: z + 0.075,
  });
  card(H, parent, arch(w * 0.82, h * 0.86), moon ? moonPrint : windowPrint, {
    x,
    y: y + 0.35,
    z: z + 0.15,
  });
  card(H, parent, rect(w * 1.04, 0.22), gold, { x, y: y + 0.05, z: z + 0.2 });
}
const pierPrint = print("#a7907e", [
  [
    "#e3c5a2",
    (g) => {
      g.fillRect(0.1, 0, 0.15, 1);
      g.fillRect(0.71, 0, 0.065, 1);
      for (const y of [0.1, 0.19, 0.78, 0.9]) g.fillRect(0, y, 1, 0.025);
    },
  ],
]);
function buttress(H, parent, x, height) {
  const baseW = 0.84;
  card(
    H,
    parent,
    [
      [-baseW, 0],
      [baseW, 0],
      [0.68, 0.52],
      [0.54, 0.76],
      [0.46, height - 0.48],
      [0.69, height - 0.22],
      [0.7, height],
      [-0.7, height],
      [-0.66, height - 0.22],
      [-0.46, height - 0.48],
      [-0.54, 0.76],
      [-0.68, 0.52],
    ],
    pierPrint,
    { x, z: 0.51 },
  );
  card(H, parent, rect(0.37, height - 0.5), darkStone, {
    x: x + 0.29,
    z: 0.76,
    y: 0.12,
    yaw: 0.9,
  });
}
// The entrance leaves fold back against the two sides of the threshold. Their hinges
// and end points are shared by the paper model and the walking collision segments.
function entrance(H, place, hall) {
  const width = 3.9,
    height = 5.9,
    hingeZ = hall.south - 0.8;
  const timber = print("#704335", [
    [
      "#bd8b5f",
      (g) => {
        for (let i = 1; i < 5; i++) g.fillRect(i / 5, 0, 0.015, 1);
        g.fillRect(0.05, 0.07, 0.9, 0.035);
      },
    ],
    [
      "#48303a",
      (g) => {
        for (const y of [0.22, 0.64]) {
          g.fillRect(0, y, 0.97, 0.055);
          poly(g, [
            [0.77, y + 0.055],
            [0.94, y + 0.15],
            [0.92, y + 0.055],
          ]);
        }
      },
    ],
    [
      brass,
      (g) => {
        for (const y of [0.245, 0.665])
          for (const x of [0.13, 0.35, 0.68, 0.88]) dot(g, x, y, 0.02, 0.012);
        star(g, 0.5, 0.83, 0.075);
      },
    ],
  ]);
  for (const side of [-1, 1]) {
    const hingeX = side * 5.5,
      yaw = side * 0.82;
    const sill = group(),
      wingWidth = hall.halfWidth - Math.abs(hingeX);
    const wingMiddle = (side * wingWidth) / 2;
    // Low cutaway masonry keeps the entrance attached to the nave without hiding the view.
    card(H, sill, rect(wingWidth, 0.72), stone, {
      x: wingMiddle,
      thickness: 0.26,
    });
    card(H, sill, rect(wingWidth, 0.14), sandstone, {
      x: wingMiddle,
      y: 0.72,
      thickness: 0.34,
    });
    buttress(H, sill, 0, height + 0.2);
    place(sill, hingeX, hingeZ, height + 0.2, { level: true, sight: true });
    H.walk.wall(hingeX, hingeZ, side * hall.halfWidth, hingeZ, {
      r: 0.2,
      name: "入口矮墙",
    });
    H.walk.solid(hingeX, hingeZ, 0.68);
    const leaf = group();
    const shape = [
      [0, 0],
      [width, 0],
      [width, height * 0.8],
      [width * 0.78, height * 0.95],
      [width * 0.42, height],
      [0, height * 0.93],
    ].map(([x, y]) => [side * x, y]);
    if (side < 0) shape.reverse();
    card(H, leaf, shape, timber, { thickness: 0.17 });
    const handle = card(H, leaf, oval(0.3, 0.46), gold, {
      x: side * width * 0.78,
      y: height * 0.38,
      z: 0.135,
    });
    handle.name = "黄铜门环";
    place(leaf, hingeX, hingeZ, height, { yaw, level: true, sight: true });
    H.walk.wall(
      hingeX,
      hingeZ,
      hingeX + side * width * Math.cos(yaw),
      hingeZ - side * width * Math.sin(yaw),
      { r: 0.18, name: "橡木大门" },
    );
  }
}
export function shell(H, place, hall) {
  const width = 2 * hall.halfWidth + 0.2;
  entrance(H, place, hall);
  const rear = group();
  rear.name = "大礼堂北墙";
  card(H, rear, rect(width, 10.6), stone);
  card(H, rear, rect(width, 0.38), gold, { y: 9.95, z: 0.1 });
  card(H, rear, rect(width, 0.33), darkStone, { y: 0.47, z: 0.15 });
  for (const x of [-21.25, -13.15, -7.75, 0, 7.75, 13.15, 21.25]) {
    windowCard(H, rear, {
      x,
      y: 1.05,
      w: x === 0 ? 6.25 : 3.65,
      h: x === 0 ? 9.15 : 6.75,
      moon: x === 0,
    });
  }
  for (const x of [-24.55, -17.05, -10.4, -4.8, 4.8, 10.4, 17.05, 24.55])
    buttress(H, rear, x, 10.0);
  const bannerShape = [
    [-1.45, 0],
    [0, 0.67],
    [1.45, 0],
    [1.45, 5.0],
    [-1.45, 5.0],
  ];
  for (const [i, x] of [-17.05, -4.6, 4.6, 17.05].entries()) {
    card(H, rear, bannerShape, bannerPrint(houses[i]), { x, y: 3.88, z: 0.99 });
    card(H, rear, rect(3.15, 0.15), gold, { x, y: 8.88, z: 1.07 });
  }
  // The far leaf of the vaulted ceiling remains in the cutaway, so its underside can be seen above the high table.
  const roof = group();
  roof.position.set(0, 10.35, -0.1);
  roof.rotation.x = -0.54;
  rear.add(roof);
  card(H, roof, rect(width, 8.8), skyPaint);
  for (const x of [-24.8, -18.6, -12.4, -6.2, 0, 6.2, 12.4, 18.6, 24.8]) {
    card(
      H,
      roof,
      [
        [x - 0.17, 0],
        [x + 0.17, 0],
        [x * 0.92 + 0.075, 8.8],
        [x * 0.92 - 0.075, 8.8],
      ],
      gold,
      { z: 0.08 },
    );
  }
  card(H, roof, rect(width, 0.16), darkStone, { y: 4.24, z: 0.07 });
  place(rear, 0, hall.north, 18, { level: true, sight: false });
  const span = 7;
  const bays = Math.round((hall.south - hall.north) / span);
  for (const side of [-1, 1]) {
    for (let idx = 0; idx < bays; idx++) {
      const z = hall.north + (idx + 0.5) * span;
      const remaining = bays - idx;
      const n = group(),
        tall = remaining === 1 ? 2.5 : remaining === 2 ? 4.45 : 8.1;
      card(H, n, rect(7.12, tall), stone);
      if (remaining > 2) windowCard(H, n, { w: 4.4, h: 6.55, y: 0.68 });
      if (remaining === 2) windowCard(H, n, { w: 2.5, h: 3.28, y: 0.58 });
      buttress(H, n, -3.29, tall + 0.35);
      card(H, n, rect(7.14, 0.23), sandstone, { y: tall - 0.15, z: 0.07 });
      place(n, side * hall.halfWidth, z, tall, {
        yaw: (-side * Math.PI) / 2,
        level: true,
        sight: false,
      });
    }
  }
}
