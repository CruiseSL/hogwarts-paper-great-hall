/*
 * The Great Hall at supper. Layered limestone arches, four embroidered standards, a moonlit
 * blue paper vault, and gilt dinner service. The front wall is cut away to follow Harry.
 * Warm sidelight meets violet shadow on the flagstones. A 32-degree lens holds the centre aisle.
 */
import * as THREE from "three";
import { createHarness } from "../vendor/papercraft/harness.js";
import { platform } from "papercraft/lib/paperkit-3d.js";
import { print, poly, group } from "./paper.js";
import { houses, brass, star } from "./houses.js";
import { shell } from "./architecture.js";
import {
  longTable,
  highTable,
  sortingHat,
  candle,
  owlLectern,
} from "./banquet.js";
import { harry } from "./harry.js";

// All floor, wall and walking coordinates use the same north/south ends.
const hall = { halfWidth: 25, north: -24.5, south: 24.5 };
const origin = [0, -3],
  tableZ = 1.6,
  tableDepth = 27.2;
const stageFront = hall.north + 8.8;
const banquetEnd = tableZ + tableDepth / 2;
const teacherZ = stageFront - 4.9,
  lecternZ = stageFront - 2.55;
const teacherWidth = 15.8,
  lecternX = 10.5;
const H = createHarness({
  ground: "#645769",
  stock: "#f5f0e8",
  play: true,
  subject: origin,
  heroHeight: 4.05,
  view: {
    pitch: 40,
    dist: 43.5,
    fov: 31.5,
    target: [0, 4.0, -10.4],
    follow: [0, -6.0],
  },
  focus: [0, 2.6, origin[1] - 3.2],
  walkArea: {
    x0: -hall.halfWidth + 0.95,
    x1: hall.halfWidth - 0.95,
    z0: hall.north + 1.2,
    z1: hall.south - 0.65,
  },
  camBox: { x0: -19.5, x1: 19.5, z0: hall.north + 1.5, z1: hall.south - 5.0 },
  bounds: { x0: -49, x1: 49, z0: -45, z1: 40 },
  light: {
    key: "#ffe7c5",
    keyDir: [-0.72, 1.22, 0.81],
    keyIntensity: 2.66,
    fill: "#c1ccf5",
    fillIntensity: 1.08,
    sky: "#e0ddf0",
    ground: "#6e6789",
    skyIntensity: 0.6,
    leak: "#67556b",
  },
  lens: {
    tint: [0.995, 0.996, 1.035],
    haze: "#8e7e91",
    hazeAmount: 0.03,
    shadowTint: "#3a3049",
    shadowLift: 0.035,
    exposure: 0.9,
    focusBand: 0.57,
    maxBlur: 7,
    vignette: 0.064,
    vignetteColor: "#302337",
  },
});
const place = (node, x, z, height, opts = {}) =>
  H.popup(null, null, { node, x, z, height, level: true, ...opts });

H.printGround(
  ({ g, ppu, X, Z, rnd }) => {
    const colors = [
      "#af9d91",
      "#b6a396",
      "#b6a699",
      "#baa99c",
      "#a99b92",
      "#bbab99",
    ];
    g.fillStyle = "#33344b";
    g.fillRect(0, 0, 98 * ppu, 85 * ppu);
    for (let i = 0; i < 1220; i++) {
      const x = rnd() * 98 - 49,
        z = rnd() * 85 - 45;
      g.fillStyle = i % 6 ? "#5f5e72" : "#c7a674";
      g.beginPath();
      g.arc(X(x), Z(z), (i % 6 ? 0.028 : 0.074) * ppu, 0, Math.PI * 2);
      g.fill();
    }
    g.save();
    g.beginPath();
    const floor = [
      X(-hall.halfWidth),
      Z(hall.north),
      hall.halfWidth * 2 * ppu,
      (hall.south - hall.north) * ppu,
    ];
    g.rect(...floor);
    g.clip();
    g.fillStyle = "#716673";
    g.fillRect(...floor);
    for (let row = 0; row < 48; row++)
      for (let col = -1; col < 34; col++) {
        const z = -45 + row * 1.86,
          x = -49 + col * 3.04 + (row % 2) * 1.52,
          xx = X(x) + 0.025 * ppu,
          zz = Z(z) + 0.025 * ppu;
        g.fillStyle = colors[Math.floor(rnd() * colors.length)];
        g.fillRect(xx, zz, 3.01 * ppu, 1.82 * ppu);
        g.fillStyle = "rgba(249,224,182,.64)";
        g.fillRect(xx, zz, 3.01 * ppu, 0.035 * ppu);
      }
    const strip = (x, z, w, d, color) => {
      g.fillStyle = color;
      g.fillRect(X(x), Z(z), w * ppu, d * ppu);
    };
    const carpetZ = stageFront - 0.16,
      carpetLength = hall.south - carpetZ;
    strip(-2.5, carpetZ, 5, carpetLength, "#663946");
    strip(-2.29, carpetZ, 4.58, carpetLength, "#9a5352");
    for (const side of [-1, 1]) {
      strip(side * 2.21, carpetZ, 0.065, carpetLength, "#e0b47d");
      strip(side * 2.0, carpetZ, 0.05, carpetLength, "#d3a773");
    }
    g.save();
    g.translate(X(0), Z(0));
    g.scale(ppu, ppu);
    for (let z = stageFront + 0.8; z < hall.south - 0.2; z += 1.35)
      for (const side of [-1, 1]) {
        const x = side * 1.75;
        g.fillStyle = "#bf8864";
        poly(g, [
          [x, z - 0.23],
          [x + 0.11, z],
          [x, z + 0.23],
          [x - 0.11, z],
        ]);
      }
    for (const z of [-8.0, 5.1, 18.2]) {
      for (const r of [1.14, 1.26]) {
        g.strokeStyle = "#d9b074";
        g.lineWidth = 0.035;
        g.beginPath();
        g.arc(0, z, r, 0, Math.PI * 2);
        g.stroke();
      }
      g.fillStyle = "#d8b175";
      star(g, 0, z, 0.92);
    }
    g.restore();
    g.restore();
  },
  { ppu: 20, seed: 394 },
);

shell(H, place, hall);
for (const h of houses) {
  const table = longTable(H, h, tableDepth);
  table.name = h.name + "长桌";
  place(table, h.x, tableZ, 2.3, { sight: false });
  H.walk.block(
    (x, z) =>
      Math.abs(x - h.x) < 2.47 && Math.abs(z - tableZ) < tableDepth / 2 + 0.12,
  );
}
const stageTop = print("#a38e87", [
  [
    brass,
    (g) => {
      g.fillRect(0, 0.04, 1, 0.014);
      g.fillRect(0.02, 0, 0.006, 1);
      g.fillRect(0.974, 0, 0.006, 1);
    },
  ],
]);
const stage = platform({
  w: 2 * hall.halfWidth - 1.8,
  d: stageFront - hall.north - 0.4,
  h: 0.45,
  paper: H.paper,
  paints: { deck: stageTop, face: print("#9b7960"), support: print("#7c6b6b") },
  print: { pxPerUnit: 24 },
});
stage.name = "教工高台";
place(stage, 0, stageFront, 0.45, { sight: false });
H.walk.add(stage);
// Raised surfaces take priority over the ground limits, including at the rear wall.
H.walk.wall(
  -hall.halfWidth,
  hall.north + 0.52,
  hall.halfWidth,
  hall.north + 0.52,
  { r: 0.27, name: "礼堂北墙" },
);
function onStage(n, x, z, height) {
  return H.popup(null, null, {
    node: n,
    parent: stage.userData.deck,
    x,
    z: z - stageFront,
    height,
    order: 7,
    level: true,
    sight: false,
  });
}
onStage(highTable(H, teacherWidth), 0, teacherZ, 4.12);
H.walk.wall(
  -teacherWidth / 2 + 0.15,
  teacherZ - 0.2,
  teacherWidth / 2 - 0.15,
  teacherZ - 0.2,
  { r: 0.94, name: "教工席" },
);
H.walk.wall(
  -teacherWidth / 2 + 0.52,
  teacherZ - 1.72,
  teacherWidth / 2 - 0.52,
  teacherZ - 1.72,
  { r: 0.53, name: "高背椅" },
);
onStage(owlLectern(H), -lecternX, lecternZ, 3.2);
H.walk.solid(-lecternX, lecternZ, 0.7);
onStage(sortingHat(H), lecternX, lecternZ, 2.91);
H.walk.solid(lecternX, lecternZ, 0.78);
const glowCanvas = document.createElement("canvas");
glowCanvas.width = 64;
glowCanvas.height = 64;
const glowCtx = glowCanvas.getContext("2d"),
  gradient = glowCtx.createRadialGradient(32, 32, 1, 32, 32, 32);
gradient.addColorStop(0, "rgba(255,222,141,.65)");
gradient.addColorStop(0.32, "rgba(255,193,93,.24)");
gradient.addColorStop(1, "rgba(255,151,60,0)");
glowCtx.fillStyle = gradient;
glowCtx.fillRect(0, 0, 64, 64);
const glowMaterial = new THREE.SpriteMaterial({
  map: new THREE.CanvasTexture(glowCanvas),
  transparent: true,
  opacity: 0.6,
  depthWrite: false,
  blending: THREE.AdditiveBlending,
});
const candles = [];
// Stagger the candles in three dimensions and leave an open strip around Harry's face.
for (let k = 0; k < 72; k++) {
  const row = Math.floor(k / 8),
    col = k % 8;
  const x = (col - 3.5) * 5.7 + Math.sin(k * 2.87) * 0.85,
    z = teacherZ + row * 4.85 + Math.sin(k * 1.93) * 1.1;
  if (Math.abs(x) < 3.2 && Math.abs(z - origin[1]) < 4.5) continue;
  const loft = 4.8 + 1.25 * Math.sin(k * 2.37) + 0.7 * (row < 2 ? 1 : 0),
    height = 0.62 + (k % 4) * 0.14;
  const frame = group(),
    wax = candle(H, height);
  frame.add(wax);
  wax.position.y = loft;
  const halo = new THREE.Sprite(glowMaterial);
  halo.position.set(0, height + 0.22, 0.1);
  halo.scale.setScalar(1.23);
  wax.add(halo);
  place(frame, x, z, loft + height + 1, { sight: false });
  candles.push({ wax, loft, phase: k * 1.43 });
}
const doll = harry(H);
H.setHero(place(doll.node, ...origin, 4.2, { scale: 1.24, sight: false }), {
  stride: doll.stride,
});
H.spots.harry = [...origin];
H.spots.houses = [0, 0];
H.spots.dais = [0, stageFront - 1.9];
const placeLabel = document.getElementById("place");
function locationName(x, z) {
  if (z < stageFront) {
    if (Math.hypot(x - lecternX, z - lecternZ) < 3.1) return "分院帽";
    if (Math.hypot(x + lecternX, z - lecternZ) < 3.1) return "猫头鹰讲台";
    return "教工高台";
  }
  if (z > banquetEnd + 0.4) return "礼堂入口";
  if (Math.abs(x) > Math.abs(houses[0].x) + 2.6)
    return x < 0 ? "西侧回廊" : "东侧回廊";
  if (Math.abs(x) < 2.6 || z < tableZ - tableDepth / 2 - 0.5) return "中央过道";
  return (
    houses.reduce((a, b) => (Math.abs(x - a.x) < Math.abs(x - b.x) ? a : b))
      .name + "长桌"
  );
}
H.onStep((t) => {
  for (const c of candles) {
    c.wax.position.y = c.loft + 0.12 * Math.sin(t * 0.77 + c.phase);
    c.wax.rotation.z = 0.033 * Math.sin(t * 0.61 + c.phase);
  }
  const p = H.hero.group.position;
  const label = locationName(p.x, p.z);
  if (placeLabel.textContent !== label) placeLabel.textContent = label;
});
H.start();
document.getElementById("status").textContent = "";
for (const b of document.querySelectorAll("#pad button")) {
  const change = (down) =>
    window.dispatchEvent(
      new KeyboardEvent(down ? "keydown" : "keyup", {
        code: b.dataset.key,
        key: b.dataset.key,
      }),
    );
  b.onpointerdown = (e) => {
    e.preventDefault();
    b.setPointerCapture(e.pointerId);
    change(true);
  };
  b.onlostpointercapture = () => change(false);
}
